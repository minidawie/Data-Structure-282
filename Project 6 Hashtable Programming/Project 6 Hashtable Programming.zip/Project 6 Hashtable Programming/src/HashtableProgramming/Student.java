package HashtableProgramming;

public class Student {
    int id;

    public Student() {}

    public Student (int id) { this.id = id; }

}
