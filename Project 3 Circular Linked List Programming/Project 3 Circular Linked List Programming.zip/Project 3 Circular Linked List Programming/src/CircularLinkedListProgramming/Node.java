package CircularLinkedListProgramming;
//this is your node class. sorry, i just copied it.
//programmer: Professor Juneja :D

public class Node {
    int data;
    Node next;

    public Node(){
        data = 0;
        next = null;
    }
    public Node(int data){
        this.data = data;
        next = null;
    }
}
